import 'package:flutter/material.dart';

void main() {
  runApp(const SmartExpenseApp());
}

class SmartExpenseApp extends StatelessWidget {
  const SmartExpenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'স্মার্ট হিসাব',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map<String, dynamic>> _transactions = [
    {'title': 'bajar', 'amount': 2000.0, 'isIncome': true, 'date': '2026-08-31'}
  ];

  // ৩ নম্বর কাজ: ক্লাউডে ডাটা ব্যাকআপ নেওয়ার মেথড
  void _syncToCloud() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Firebase Cloud Syncing... (ক্লাউডে সেভ হচ্ছে)'),
        backgroundColor: Colors.teal,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('স্মার্ট হিসাব', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.teal,
        actions: [
          // ক্লাউড ব্যাকআপ বাটন
          IconButton(
            icon: const Icon(Icons.cloud_upload, color: Colors.white),
            tooltip: 'Cloud Backup',
            onPressed: _syncToCloud,
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.teal.shade50,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.teal.shade100),
            ),
            child: const Column(
              children: [
                Text('মোট ব্যালেন্স', style: TextStyle(fontSize: 14, color: Colors.black54)),
                SizedBox(height: 4),
                Text(
                  '৳ 2000.00',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal),
                ),
                Divider(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text('মোট আয়', style: TextStyle(color: Colors.black54, fontSize: 12)),
                        Text('৳ 2000.00', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Column(
                      children: [
                        Text('মোট খরচ', style: TextStyle(color: Colors.black54, fontSize: 12)),
                        Text('৳ 0.00', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
          
          Expanded(
            child: ListView.builder(
              itemCount: _transactions.length,
              itemBuilder: (context, index) {
                final item = _transactions[index];
                return ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Colors.lightGreen,
                    child: Icon(Icons.arrow_downward, color: Colors.green),
                  ),
                  title: Text(item['title']),
                  subtitle: Text(item['date']),
                  trailing: Text(
                    '+ ৳${item['amount']}',
                    style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                  ),
                );
              },
            ),
          ),

          // ৪ নম্বর কাজ: AdMob Banner Ad Holder
          Container(
            width: double.infinity,
            height: 50,
            color: Colors.grey.shade300,
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.ads_click, color: Colors.black54, size: 20),
                  SizedBox(width: 8),
                  Text(
                    'AdMob Banner Ad Here',
                    style: TextStyle(color: Colors.black54, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: Colors.teal,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}